package com.example.gasguardot

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class DashboardActivity : AppCompatActivity() {

    // Variable para la base de datos en tiempo real
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // 1. Vincular los elementos visuales del diseño (activity_dashboard.xml)
        val gasLevelText = findViewById<TextView>(R.id.gasLevelText)
        val emergencyButton = findViewById<Button>(R.id.emergencyButton)

        // 2. Conectar a Firebase Realtime Database
        database = FirebaseDatabase.getInstance("https://gasguard-ot-default-rtdb.firebaseio.com/").reference

        // 3. Leer el nivel de gas en tiempo real desde la ESP32 (Ruta: sensores/gas)
        database.child("sensores").child("gas").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val nivelGas = snapshot.getValue(Int::class.java)

                if (nivelGas != null) {
                    // Actualiza el texto en la pantalla
                    gasLevelText.text = "$nivelGas%"

                    // Cambia el color visual a rojo si supera el umbral de peligro (ej. 50%)
                    if (nivelGas > 50) {
                        gasLevelText.setTextColor(android.graphics.Color.RED)
                    } else {
                        gasLevelText.setTextColor(android.graphics.Color.parseColor("#38A169"))
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@DashboardActivity, "Error de conexión OT", Toast.LENGTH_SHORT).show()
            }
        })

        // 4. Botón de emergencia: Enviar orden de cierre al servomotor (Ruta: actuadores/servo)
        emergencyButton.setOnClickListener {
            // Escribimos un '1' en la base de datos para que la ESP32 active el motor
            database.child("actuadores").child("servo").setValue(1)
                .addOnSuccessListener {
                    Toast.makeText(this, "¡CIERRE DE EMERGENCIA ACTIVADO!", Toast.LENGTH_LONG).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Fallo en envío de comando", Toast.LENGTH_SHORT).show()
                }
        }
    }
}