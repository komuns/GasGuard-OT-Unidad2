package com.example.gasguardot

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {

    // Declarar la variable de autenticación de Firebase
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 1. Inicializar el motor de Firebase Auth
        auth = FirebaseAuth.getInstance()

        // 2. Vincular los botones y textos del diseño (activity_main.xml) con el código
        val emailEditText = findViewById<EditText>(R.id.emailEditText)
        val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
        val loginButton = findViewById<Button>(R.id.loginButton)

        // 3. Programar la acción al hacer clic en el botón "INICIAR SESIÓN"
        loginButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            // Evitar que el sistema intente validar campos en blanco
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Por favor, ingresa correo y contraseña", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // 4. Enviar los datos a la base de seguridad de Firebase
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        // Si el usuario existe, mostrar mensaje y saltar al Dashboard
                        Toast.makeText(this, "Acceso Autorizado al Panel OT", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this, DashboardActivity::class.java)
                        startActivity(intent)
                        finish() // Cierra el Login para que no puedan volver atrás usando la flecha del celular
                    } else {
                        // Si la contraseña es incorrecta o el usuario no existe
                        Toast.makeText(this, "Error de credenciales de seguridad", Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }
}